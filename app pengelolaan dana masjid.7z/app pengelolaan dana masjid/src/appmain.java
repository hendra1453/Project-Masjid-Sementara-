import view.admin;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hendra
 */
public class appmain {
    public static void main (String [] args){
        admin adm  = new admin();
        adm.setVisible(true);
          
    }
}
