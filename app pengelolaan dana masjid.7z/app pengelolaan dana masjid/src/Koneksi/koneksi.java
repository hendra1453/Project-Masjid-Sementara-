package koneksi;

import java.sql.*;
import javax.swing.JOptionPane;

public class koneksi {
    public static Connection conn;
    public static Connection koneksiDB()throws SQLException{
   try{
       String url = "jdbc:mysql://localhost:3306/kas_masjid";
       String user = "root";
       String pass = "";
       DriverManager.registerDriver(new com.mysql.jdbc.Driver());
       conn = DriverManager.getConnection(url,user,pass);
//       JOptionPane.showMessageDialog(null, "Assalamu'alaykum");
   }catch(Exception e) {
       JOptionPane.showMessageDialog(null, "Gagal Koneksi"+e.getMessage());
    }
   return conn;
        }
   }
