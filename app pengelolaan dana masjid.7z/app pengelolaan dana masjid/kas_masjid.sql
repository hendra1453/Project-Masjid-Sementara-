-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2017 at 03:26 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kas_masjid`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`, `id`) VALUES
('admin', 'admin', 1),
('hendra', 'hendra', 2);

-- --------------------------------------------------------

--
-- Table structure for table `dana_sosial`
--

CREATE TABLE `dana_sosial` (
  `idsosial` varchar(20) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `penyumbang` varchar(30) DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `nominal` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dana_sosial_keluar`
--

CREATE TABLE `dana_sosial_keluar` (
  `idsosial` varchar(20) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `penyumbang` varchar(30) DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `nominal` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dana_syiar`
--

CREATE TABLE `dana_syiar` (
  `idsyiar` varchar(20) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `penyumbang` varchar(30) DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `nominal` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dana_syiar_keluar`
--

CREATE TABLE `dana_syiar_keluar` (
  `idsyiar` varchar(20) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `penyumbang` varchar(30) DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `nominal` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dana_waqaf`
--

CREATE TABLE `dana_waqaf` (
  `idwaqaf` varchar(20) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `penyumbang` varchar(30) DEFAULT NULL,
  `jenis_waqaf` varchar(100) DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `nominal` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dana_waqaf_keluar`
--

CREATE TABLE `dana_waqaf_keluar` (
  `idwaqaf` varchar(20) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `penyumbang` varchar(30) DEFAULT NULL,
  `jenis_waqaf` varchar(100) DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `nominal` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `data_mahasiswa`
--

CREATE TABLE `data_mahasiswa` (
  `nim` varchar(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `jk` varchar(30) DEFAULT NULL,
  `fakultas` varchar(45) DEFAULT NULL,
  `jurusan` varchar(45) DEFAULT NULL,
  `kontak` varchar(12) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kas_keluar`
--

CREATE TABLE `kas_keluar` (
  `idkas` varchar(20) NOT NULL,
  `tanggalkas` date DEFAULT NULL,
  `jenis_kas` varchar(20) DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `nominal` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kas_masuk`
--

CREATE TABLE `kas_masuk` (
  `id_kas` varchar(20) NOT NULL,
  `tanggalkas` varchar(255) DEFAULT NULL,
  `jenis_kas` varchar(20) DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `nominal` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kas_masuk`
--

INSERT INTO `kas_masuk` (`id_kas`, `tanggalkas`, `jenis_kas`, `keterangan`, `nominal`) VALUES
('12', '20171208', '4545', 'd45', 12),
('K0003', '20171208', '4545', 'd45', 12),
('K0004', '20171208', 'Infaq', 'd45', 12),
('K0005', '20171222', 'Infaq', 'ada', 12),
('K0006', '20171215', 'Infaq', 'sds', 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dana_sosial`
--
ALTER TABLE `dana_sosial`
  ADD PRIMARY KEY (`idsosial`);

--
-- Indexes for table `dana_sosial_keluar`
--
ALTER TABLE `dana_sosial_keluar`
  ADD PRIMARY KEY (`idsosial`);

--
-- Indexes for table `dana_syiar`
--
ALTER TABLE `dana_syiar`
  ADD PRIMARY KEY (`idsyiar`);

--
-- Indexes for table `dana_syiar_keluar`
--
ALTER TABLE `dana_syiar_keluar`
  ADD PRIMARY KEY (`idsyiar`);

--
-- Indexes for table `dana_waqaf`
--
ALTER TABLE `dana_waqaf`
  ADD PRIMARY KEY (`idwaqaf`);

--
-- Indexes for table `dana_waqaf_keluar`
--
ALTER TABLE `dana_waqaf_keluar`
  ADD PRIMARY KEY (`idwaqaf`);

--
-- Indexes for table `data_mahasiswa`
--
ALTER TABLE `data_mahasiswa`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `kas_keluar`
--
ALTER TABLE `kas_keluar`
  ADD PRIMARY KEY (`idkas`);

--
-- Indexes for table `kas_masuk`
--
ALTER TABLE `kas_masuk`
  ADD PRIMARY KEY (`id_kas`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
